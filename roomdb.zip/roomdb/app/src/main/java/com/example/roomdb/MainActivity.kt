package com.example.roomdb

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.launch

import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var userAdapter: UserAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        lifecycleScope.launch {
            loadUsers()
        }


            lifecycleScope.launch {
                addUser("John Doe", 25)
                addUser("John will", 25)
                addUser("Jane Smith", 28)
                addUser("Bob Johnson", 32)
                addUser("Alice Brown", 24)
                addUser("Mike Davis", 30)
                loadUsers()
            }

    }

    private suspend fun loadUsers() {
        val userDao = MyApplication.database.userDao()
        val users = userDao.getAllUsers()
        userAdapter = UserAdapter(users)
        recyclerView.adapter = userAdapter
    }

    private suspend fun addUser(name: String, age: Int) {
        val userDao = MyApplication.database.userDao()
        val user = User(0, name, age)
        userDao.insert(user)
    }
}
