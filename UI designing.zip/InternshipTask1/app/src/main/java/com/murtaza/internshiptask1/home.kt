package com.murtaza.internshiptask1

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat


import android.widget.Toast
import com.google.android.material.bottomnavigation.BottomNavigationView

class home : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        // Find the CardView by its ID
        val cardManageEmployees = findViewById<androidx.cardview.widget.CardView>(R.id.c1)

        // Set OnClickListener on the CardView
        cardManageEmployees.setOnClickListener {
            // Intent to start ManageEmployeesActivity
            val intent = Intent(this, managemployees::class.java)
            startActivity(intent)
        }


        // Initialize and setup the bottom navigation view
        val bottomNavigationView: BottomNavigationView = findViewById(R.id.bottom_navigation)
        bottomNavigationView.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    showToast("Home")
                    return@setOnNavigationItemSelectedListener true
                }
                R.id.nav_map -> {
                    showToast("Map")
                    return@setOnNavigationItemSelectedListener true
                }
                R.id.nav_chat -> {
                    showToast("Chat")

                    val intent = Intent(this, home2::class.java)
                    startActivity(intent)

                    return@setOnNavigationItemSelectedListener true
                }
                R.id.nav_profile -> {
                    showToast("Profile")
                    return@setOnNavigationItemSelectedListener true
                }
            }
            false
        }

        // Set the initial fragment on first load
        if (savedInstanceState == null) {
            bottomNavigationView.selectedItemId = R.id.nav_home
        }
    }



    private fun showToast(message: String) {
        Toast.makeText(this, "Clicked: $message", Toast.LENGTH_SHORT).show()
    }
}
