package com.murtaza.internshiptask1
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class managemployees : ComponentActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: MentorAdapter
    private lateinit var searchEditText: EditText
    private lateinit var searchButton: Button
    private lateinit var backButton: ImageView

    private var mentorList = createDummyData()
    private var filteredList: ArrayList<Mentor> = ArrayList(mentorList)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_managemployees)

        // Initialize RecyclerView
        recyclerView = findViewById(R.id.recyclerview)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = MentorAdapter(filteredList)
        recyclerView.adapter = adapter

        // Initialize search EditText and Button
        searchEditText = findViewById(R.id.searchEditText)
        searchButton = findViewById(R.id.searchButton)

        backButton = findViewById(R.id.backbutton)

        backButton.setOnClickListener{

            val intent = Intent(this, home2::class.java)
            startActivity(intent)


        }



        // Implement text change listener for search EditText
        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                filterMentors(s.toString())
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        // Implement click listener for search Button
        searchButton.setOnClickListener {
            val searchText = searchEditText.text.toString()
            filterMentors(searchText)
        }
    }

    // Filter mentors based on search text
    private fun filterMentors(query: String) {
        filteredList.clear()
        if (query.isEmpty()) {
            filteredList.addAll(mentorList)
        } else {
            val lowerCaseQuery = query.toLowerCase()
            mentorList.forEach { mentor ->
                if (mentor.name.toLowerCase().contains(lowerCaseQuery)) {
                    filteredList.add(mentor)
                }
            }
        }
        adapter.notifyDataSetChanged()
    }

    // Create some dummy data
    private fun createDummyData(): ArrayList<Mentor> {
        val data = ArrayList<Mentor>()
        data.add(Mentor("John Doe", "Online"))
        data.add(Mentor("Jane Smith", "Offline"))
        data.add(Mentor("Alice Johnson", "Online"))
        data.add(Mentor("Bob Williams", "Offline"))
        data.add(Mentor("Emily Brown", "Online"))
        data.add(Mentor("David Wilson", "Offline"))
        data.add(Mentor("Sarah Jones", "Online"))
        data.add(Mentor("Michael Davis", "Offline"))
        data.add(Mentor("Jennifer Garcia", "Online"))
        data.add(Mentor("Christopher Rodriguez", "Offline"))
        // Add more dummy data as needed
        return data
    }
}

// Mentor Data Class
data class Mentor(val name: String, val status: String)

// Mentor Adapter
class MentorAdapter(private val mentorList: ArrayList<Mentor>) :
    RecyclerView.Adapter<MentorAdapter.ViewHolder>() {

    class ViewHolder(itemView: android.view.View) : RecyclerView.ViewHolder(itemView) {
        val profileImageView: ImageView = itemView.findViewById(R.id.textView12)
        val mentorNameTextView: TextView = itemView.findViewById(R.id.textViewmentorname)
        val onlineTextView: TextView = itemView.findViewById(R.id.lasttext)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.row_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val mentor = mentorList[position]
        holder.mentorNameTextView.text = mentor.name
        holder.onlineTextView.text = mentor.status
        // Set the image (you'll need to have a placeholder image resource)
        // holder.profileImageView.setImageResource(R.drawable.ic_profile) // Replace with actual image
    }

    override fun getItemCount(): Int {
        return mentorList.size
    }
}
