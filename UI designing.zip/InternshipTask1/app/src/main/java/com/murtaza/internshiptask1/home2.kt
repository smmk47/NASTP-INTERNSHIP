package com.murtaza.internshiptask1

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import android.widget.ToggleButton
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class home2 : AppCompatActivity() {

    private val themeTitleList = arrayOf("Light","Dark","Auto (System Default)")


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home2)

        val changeThemeBtn = findViewById<Button>(R.id.changeThemeBtn)




        val sharedPreferenceManger = SharedPreferenceManger(this)
        var checkedTheme = sharedPreferenceManger.theme
//        themeTxt.text = "Theme: ${themeTitleList[sharedPreferenceManger.theme]}"
        val themeDialog = MaterialAlertDialogBuilder(this)
            .setTitle("Theme")
            .setPositiveButton("Ok"){_,_ ->
                sharedPreferenceManger.theme = checkedTheme
                AppCompatDelegate.setDefaultNightMode(sharedPreferenceManger.themeFlag[checkedTheme])
//                themeTxt.text = "Theme: ${themeTitleList[sharedPreferenceManger.theme]}"
            }
            .setSingleChoiceItems(themeTitleList,checkedTheme){_, which ->
                checkedTheme = which
            }
            .setCancelable(false)

        changeThemeBtn.setOnClickListener {
            themeDialog.show()
        }



        val cardManageEmployees = findViewById<androidx.cardview.widget.CardView>(R.id.c1)

        cardManageEmployees.setOnClickListener {
            val intent = Intent(this, managemployees::class.java)
            startActivity(intent)
        }



        val viewPager: ViewPager2 = findViewById(R.id.viewPager)

        val cardContents = listOf("", "", "", "")
        val adapter = CardAdapter(cardContents)

        viewPager.adapter = adapter



        val bottomNavigationView: BottomNavigationView = findViewById(R.id.bottom_navigation)
        bottomNavigationView.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    showToast("Home")
                    true
                }
                R.id.nav_map -> {
                    showToast("Map")
                    true
                }
                R.id.nav_chat -> {
                    showToast("Chat")
                    true
                }
                R.id.nav_profile -> {
                    showToast("Profile")

                    val intent = Intent(this, home2::class.java)
                    startActivity(intent)

                    true
                }
                else -> false
            }
        }

        if (savedInstanceState == null) {
            bottomNavigationView.selectedItemId = R.id.nav_home
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, "Clicked: $message", Toast.LENGTH_SHORT).show()
    }
}
