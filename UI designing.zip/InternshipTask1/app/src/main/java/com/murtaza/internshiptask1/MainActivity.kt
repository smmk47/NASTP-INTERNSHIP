package com.murtaza.internshiptask1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.logging.Handler


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Delay for 2 seconds before starting HomeActivity
        android.os.Handler().postDelayed({
            val intent = Intent(this@MainActivity, home2::class.java)
            startActivity(intent)
            finish() // Optional: Finish current activity so user can't go back to it with back button
        }, 2000) // 2000 milliseconds = 2 seconds
    }
}








