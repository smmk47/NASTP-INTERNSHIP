package com.example.retrofit

import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET

interface ApiService {
    @GET("employee?noofRecords=10&idStarts=1001")
    fun getEmployees(): Call<List<Employee>>
}

object ApiClient {
    private const val BASE_URL = "https://hub.dummyapis.com/"
    val retrofit: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }
}
