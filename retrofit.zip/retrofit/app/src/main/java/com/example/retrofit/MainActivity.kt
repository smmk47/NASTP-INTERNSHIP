package com.example.retrofit

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: EmployeeAdapter
    private val employeeList: MutableList<Employee> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = EmployeeAdapter(employeeList)
        recyclerView.adapter = adapter

        fetchEmployees()
    }

    private fun fetchEmployees() {
        val apiService = ApiClient.retrofit.create(ApiService::class.java)
        val call = apiService.getEmployees()

        call.enqueue(object : Callback<List<Employee>> {
            override fun onResponse(call: Call<List<Employee>>, response: Response<List<Employee>>) {
                if (response.isSuccessful) {
                    response.body()?.let {
                        employeeList.addAll(it)
                        adapter.notifyDataSetChanged()
                        logEmployeeData(it)  // Log the employee data
                    }
                }
            }

            override fun onFailure(call: Call<List<Employee>>, t: Throwable) {
                Log.e("MainActivity", "Error fetching employees", t)
            }
        })
    }

    private fun logEmployeeData(employees: List<Employee>) {
        for (employee in employees) {
            Log.d("MainActivity", "ID: ${employee.id}, Name: ${employee.firstName} ${employee.lastName}, Email: ${employee.email}, Contact: ${employee.contactNumber}, Age: ${employee.age}, DOB: ${employee.dob}, Salary: ${employee.salary}, Address: ${employee.address}")
        }
    }
}
